Buenas soy el creador del juego AlienAttack
Antes que nada quiero decirles que espero que les guste este juego
Por si hay algun tipo de confusion el archivo que tienes que abrir es el de Menu_AlienAttack.py cuando le des a start tendrás que esperar unos 5 segundos. Después de esos 5 segundos empezará la partida

Explicaré un poco como funciona el juego

-- Objetivo

	# Acabar con todos los aliens que aparezcan hasta que salga la pantalla de You win
	# Que los aliens no te maten


-- Controles

	# Boton Derecha --> Moviento en uno a la derecha
	# Boton Izquierda --> Movimiento en uno a la izquierda
	# Boton Espacio --> Disparo de tu nave


Eso es todo lo que tenia que comentar, lo dicho espero que te guste el juego!!!


