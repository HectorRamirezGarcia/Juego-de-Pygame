#!/usr/bin/python
# -*- coding: utf-8 -*-
#Colores primarios= Rojo, Verde y Azul

import pygame,sys, time
from pygame.locals import *
from classes import Nave
from classes import Invasor as Enemigo


# Variable globales
ancho= 1000
alto = 700
juego=0
listaEnemigos = []
rectangulo = pygame.Rect(700,700,1000,0)

def detenerJuego():
	for enemigo in listaEnemigos:
		for disparo in enemigo.listaDisparo:
			enemigo.listaDisparo.remove(disparo)
			
		enemigo.conquista= True

def cargarEnemigos():
	deadenemigos=0
	posx = 50
	for x in range(1, 5):
		enemigo = Enemigo(posx,200,20,'img/marcianoA.jpg', 'img/MarcianoB.jpg',)
		listaEnemigos.append(enemigo)
		posx = posx + 200
			
	posx = 50
	for x in range(1, 5):
		enemigo = Enemigo(posx,100,20,'img/Marciano2A.jpg', 'img/Marciano2B.jpg',)
		listaEnemigos.append(enemigo)
		posx = posx + 200
		
	posx = 50
	for x in range(1, 5):
		enemigo = Enemigo(posx,-50,20,'img/Marciano3A.jpg', 'img/Marciano3B.jpg',)
		listaEnemigos.append(enemigo)
		posx = posx + 200
		
def SpaceInvader():
	pygame.init()
	pygame.mouse.set_visible(0)
	ventana = pygame.display.set_mode((ancho,alto))
	pygame.display.set_caption("Alien Attack")
	
	ImagenFondo = pygame.image.load('img/Fondo.jpg')
	ImagenLimite = pygame.image.load('img/Limite.jpg')
	pygame.draw.rect(ventana, (255,255,255), rectangulo)
	
	pygame.mixer.music.load('sounds/Music.mp3')
	pygame.mixer.music.play(5)
	
	score=0
	enemydel=0
	miFuenteSistema = pygame.font.SysFont("Arial", 70)
	Texto = miFuenteSistema.render("Game Over",0,(200,200,40))
	You_win = miFuenteSistema.render("You win", 0,(200,200,40))
	
	jugador = Nave.naveEspacial(ancho, alto)
	cargarEnemigos()
	
	enJuego = True
	
	reloj = pygame.time.Clock()
	
	while True:
		reloj.tick(60)
		tiempo = pygame.time.get_ticks()/1000
		for evento in pygame.event.get():
			if evento.type == QUIT:
				pygame.quit()
				sys.exit
			if enJuego== True:
				if evento.type==pygame.KEYDOWN:
					if evento.key == K_LEFT:
						jugador.movimientoIzquierda()
					elif evento.key == K_RIGHT:
						jugador.movimientoDerecha()
					elif evento.key == K_SPACE:
						x,y= jugador.rect.center
						jugador.dispara(x,y)
						
		ventana.blit(ImagenFondo, (0,0))
		ventana.blit(ImagenLimite, (385,0))
		jugador.dibujar(ventana)	
		if len(jugador.listaDisparo)>0:
			for x in jugador.listaDisparo:
				x.dibujar(ventana)
				x.trayectoria()
				if x.rect.top <-10:
					jugador.listaDisparo.remove(x)
				else:
					for enemigo in listaEnemigos:
						if x.rect.colliderect(enemigo.rect):
							listaEnemigos.remove(enemigo)
							jugador.listaDisparo.remove(x)
							score+=100
							enemydel+=1
							
		miFuenteScore = pygame.font.SysFont("ComicSans", 30)
		Score = miFuenteScore.render("Score "+str(score), 0,(100,200,120))
		Enemydel = miFuenteScore.render("Kills "+str(enemydel), 0,(100,200,120))
		score_pos = (840, 10)
		enemydel_pos = (840, 30)
		ventana.blit(Score, score_pos)
		ventana.blit(Enemydel, enemydel_pos)
		
		if enemydel==12:
			enJuego=False
			ventana.blit(You_win, (300,300))
						
		if len(listaEnemigos)>0:
			for enemigo in listaEnemigos:
				enemigo.comportamien(tiempo)
				enemigo.dibujar(ventana)
				
				if len(enemigo.listaDisparo)>0:
					for x in enemigo.listaDisparo:
						x.dibujar(ventana)
						x.trayectoria()
						if x.rect.colliderect(jugador.rect):
							jugador.destruccion()
							enJuego=False
							detenerJuego()
						if x.rect.top >900:
							enemigo.listaDisparo.remove(x)
						else:
							for disparo in jugador.listaDisparo:
								if x.rect.colliderect(disparo.rect):
									jugador.listaDisparo.remove(disparo)
									enemigo.listaDisparo.remove(x)
									score+=50
									
				if enemigo.rect.colliderect(jugador.rect):
					jugador.destruccion()
					enJuego=False
					detenerJuego()
						
				if enemigo.rect.colliderect(rectangulo):
					jugador.destruccion()
					enJuego=False
					detenerJuego()
						
		if enJuego==False:
			pygame.mixer.music.fadeout(3000)
			if enemydel != 12:
				ventana.blit(Texto,(300,300))
			
					
		pygame.display.update()
		
SpaceInvader()
