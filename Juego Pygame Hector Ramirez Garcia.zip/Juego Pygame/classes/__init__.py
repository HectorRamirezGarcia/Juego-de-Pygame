from Invasor import Invasor
from Nave import naveEspacial
from Proyectil import Proyectil

