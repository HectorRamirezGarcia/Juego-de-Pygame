import pygame
import Proyectil

class naveEspacial(pygame.sprite.Sprite):
	
	"""Clase para las naves """
	def __init__(self, ancho, alto):
		pygame.sprite.Sprite.__init__(self)
		self.ImagenNave = pygame.image.load('img/nave.jpg')
		self.ImagenExplosion = pygame.image.load("img/explosion.jpg")
		
		self.rect = self.ImagenNave.get_rect()
		self.rect.centerx = ancho/2
		self.rect.centery = alto-30
		
		self.listaDisparo = []
		self.Vida = True
		self.velocidad= 20
		
		self.sonidoDisparo = pygame.mixer.Sound("sounds/Disparo.wav")
		self.sonidoExplosion = pygame.mixer.Sound("sounds/Explosion.wav")
		
	def movimientoIzquierda(self):
		self.rect.left -= self.velocidad
		self.__movimiento()
		
	def movimientoDerecha(self):
		self.rect.right += self.velocidad
		self.__movimiento()
		
	def movimientoArriba(self):
		self.rect.top -= self.velocidad
		self.__movimiento()
		
	def movimientoAbajo(self):
		self.rect.top += self.velocidad
		self.__movimiento()
		
	def __movimiento(self):
		if self.Vida == True:
			if self.rect.left <=0:
				self.rect.left =0
			elif self.rect.right>780:
				self.rect.right = 770
		
	def dispara(self,x,y):
		print "Disparo "
		miProyectil = Proyectil.Proyectil(x,y,"img/disparoa.jpg",True)
		self.listaDisparo.append(miProyectil)
		self.sonidoDisparo.play()
		
	def dibujar (self, superficie):
		superficie.blit(self.ImagenNave, self.rect)
		
	def destruccion(self):
		self.sonidoExplosion.play()
		self.Vida=False
		self.velocidad=0
		self.ImagenNave = self.ImagenExplosion
		

