# Chelin Tutorials Todos los Derechos Reservados
# www.chelintutorials.blogspot.com
#Como cambiar el fondo con botones

import pygame 
import time
 # importo el modulo

class Cursor(pygame.Rect):
    def __init__(self):
        pygame.Rect.__init__(self,0,0,1,1)
    def update(self):
        self.left,self.top=pygame.mouse.get_pos()

class Boton(pygame.sprite.Sprite):
    def __init__(self,imagen1,imagen2,x=200,y=200):
        self.imagen_normal=imagen1
        self.imagen_seleccion=imagen2
        self.imagen_actual=self.imagen_normal
        self.rect=self.imagen_actual.get_rect()
        self.rect.left,self.rect.top=(x,y)
        
    def update(self,pantalla,cursor):
        if cursor.colliderect(self.rect):
            self.imagen_actual=self.imagen_seleccion
        else: self.imagen_actual=self.imagen_normal
        pantalla.blit(self.imagen_actual,self.rect)
         

#funcion main
def main():
    pygame.init() # inicializo el modulo
    
    # fijo las dimensiones de la pantalla a 300,300 y creo una superficie que va ser la principal
    pantalla=pygame.display.set_mode((1200,600))
    
    pygame.display.set_caption("Alien Attack") # Titulo de la Ventana
    #creo un reloj para controlar los fps
    reloj1=pygame.time.Clock()
    ImagenFondo = pygame.image.load('img/Fondo.jpg')
    ImagenTitulo= pygame.image.load('img/Titulo.jpg')
    BotonEmpezar=pygame.image.load("img/Boton Start.jpg")
    BotonEmpezar2=pygame.image.load("img/Boton Start2.jpg")
    BotonSalir=pygame.image.load("img/Boton Salir.jpg")  
    BotonSalir2=pygame.image.load("img/Boton Salir2.jpg") 
    
    boton1=Boton(BotonEmpezar, BotonEmpezar2, 550,300)
    boton2=Boton(BotonSalir, BotonSalir2, 550,400)
    cursor1=Cursor()
    tiempo=5
    
    salir=False
    #LOOP PRINCIPAL
    while salir!=True:
        #recorro todos los eventos producidos
        #en realidad es una lista
        reloj1.tick(20)#operacion para que todo corra a 20fps
        
        for event in pygame.event.get():
            if event.type==pygame.MOUSEBUTTONDOWN:
                if cursor1.colliderect(boton1.rect):
					for contador in range (5, 0, -1):
						time.sleep(1)
						print contador
					import AlienAttack
                if cursor1.colliderect(boton2.rect):
                    salir=True
            
            # pygame.QUIT( cruz de la ventana)
            if event.type == pygame.QUIT:
                salir=True
 
        pantalla.blit(ImagenFondo, (0,0))
        pantalla.blit(ImagenTitulo, (320,-40))      
        cursor1.update()
        boton1.update(pantalla,cursor1)
        boton2.update(pantalla, cursor1)
        
        pygame.display.update() #actualizo el display
    pygame.quit()
    
main() 
